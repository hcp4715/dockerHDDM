The following people have contributed to HDDM:

* Thomas Wiecki
* Imri Sofer
* Alexander Fengler
* Lakshmi Govindarajan
* Krishn Bera
* Michael J. Frank
* Guido Biele
* Øystein Sandvik
* Mads Pedersen



