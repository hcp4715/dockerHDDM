.. index:: Demos
.. _chap_demos:

*************
Demos
*************

.. toctree::
    :maxdepth: 2

    demo_gonogo
    demo_RLHDDMtutorial
    demo_HDDMnnRL