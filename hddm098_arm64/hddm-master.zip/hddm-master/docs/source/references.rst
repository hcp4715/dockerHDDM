.. index:: References
.. _chap_refs:

References
----------

..  bibliography:: zzz_hddm.bib