hddm.simulators package
=======================

Submodules
----------

hddm.simulators.basic\_simulator module
---------------------------------------

.. automodule:: hddm.simulators.basic_simulator
   :members:
   :undoc-members:
   :show-inheritance:

hddm.simulators.hddm\_dataset\_generators module
------------------------------------------------

.. automodule:: hddm.simulators.hddm_dataset_generators
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: hddm.simulators
   :members:
   :undoc-members:
   :show-inheritance:
