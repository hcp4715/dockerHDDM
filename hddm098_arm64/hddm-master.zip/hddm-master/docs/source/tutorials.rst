.. index:: Tutorials
.. _chap_tutorial:

***************
Basic Tutorials
***************

.. toctree::
   :maxdepth: 2

   tutorial_basic_hddm
   tutorial_post_pred
   tutorial_regression_stimcoding
   tutorial_gonogo_chisquare
   lan_tutorial
   tutorial_set_parameter_defaults
   tutorial_model_plot
   demo_RLHDDMtutorial
   demo_HDDMnnRL