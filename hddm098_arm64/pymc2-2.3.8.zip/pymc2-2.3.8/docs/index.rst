.. PyMC documentation master file, created by sphinx-quickstart on Tue Jan 25 12:00:55 2011.

PyMC User's Guide
=================

Contents:

.. toctree::
   :maxdepth: 2
   :numbered:

   README
   INSTALL
   tutorial
   modelbuilding
   modelfitting
   database
   modelchecking
   extending
   distributions
   conclusion
   theory
   references

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

