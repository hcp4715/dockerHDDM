"""
Examples for PyMC.
"""
